<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Management</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="header-content">
            <div class="logo">
                <span class="logo-icon">🎓</span>
                Student Management System
            </div>
            <nav>
                <ul>
                    <li><a href="student.php" class="nav-link active">Students</a></li>
                    <li><a href="course.php" class="nav-link">Courses</a></li>
                    <li><a href="courseadd.php" class="nav-link">Registration</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container">
        <?php
        $conn = mysqli_connect("localhost", "root", "", "student_management");

        if (!$conn) {
            die("SQL connection problem: " . mysqli_connect_error());
        }

        if (isset($_POST['submit'])) {
            $username = mysqli_real_escape_string($conn, $_POST['username']);
            $sapid = mysqli_real_escape_string($conn, $_POST['sapid']);
            $fathername = mysqli_real_escape_string($conn, $_POST['fathername']);

            // Check if fields are empty
            if (empty($username) || empty($sapid) || empty($fathername)) {
                echo "<div class='alert alert-danger'>Please fill in all the fields!</div>";
            } else {
                $query = "INSERT INTO users (username, sapid, fathername) VALUES ('$username', '$sapid', '$fathername')";
                $result = mysqli_query($conn, $query);

                if ($result) {
                    echo "<div class='alert alert-success'>Student record inserted successfully!</div>";
                } else {
                    echo "<div class='alert alert-danger'>Error inserting record: " . mysqli_error($conn) . "</div>";
                }
            }
        }
        ?>

        <div class="card">
            <div class="card-header">
                <h2 class="card-title">
                    <span class="icon">👨‍🎓</span>
                    Add New Student
                </h2>
                <p class="card-subtitle">Register a new student in the system</p>
            </div>
            <div class="card-body">
                <form action="" method="post" class="advanced-form">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="username" class="form-label">
                                <span class="label-icon">👤</span>
                                Username
                            </label>
                            <input type="text" name="username" class="form-input" placeholder="Enter student username">
                            <div class="form-hint">Enter the student's preferred username</div>
                        </div>
                        
                        <div class="form-group">
                            <label for="sapid" class="form-label">
                                <span class="label-icon">🆔</span>
                                SAP ID
                            </label>
                            <input type="text" name="sapid" class="form-input" placeholder="Enter SAP ID">
                            <div class="form-hint">Unique student identification number</div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="fathername" class="form-label">
                            <span class="label-icon">👨‍👦</span>
                            Father's Name
                        </label>
                        <input type="text" name="fathername" class="form-input" placeholder="Enter father's name">
                        <div class="form-hint">Full name of student's father</div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" name="submit" class="btn btn-primary">
                            <span class="btn-icon">➕</span>
                            Add Student
                        </button>
                        <button type="reset" class="btn btn-secondary">
                            <span class="btn-icon">🔄</span>
                            Reset Form
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h2 class="card-title">
                    <span class="icon">📊</span>
                    Student Records
                </h2>
                <div class="card-actions">
                    <span class="record-count">Total: 
                        <?php
                        $count_query = "SELECT COUNT(*) as total FROM users";
                        $count_result = mysqli_query($conn, $count_query);
                        $count_data = mysqli_fetch_assoc($count_result);
                        echo $count_data['total'];
                        ?>
                    </span>
                </div>
            </div>
            <div class="card-body">
                <div class="table-container">
                    <table class="advanced-table">
                        <thead>
                            <tr>
                                <th class="sortable" data-sort="username">
                                    <span>👤 Username</span>
                                    <span class="sort-indicator">↓</span>
                                </th>
                                <th class="sortable" data-sort="sapid">
                                    <span>🆔 SAP ID</span>
                                    <span class="sort-indicator">↓</span>
                                </th>
                                <th class="sortable" data-sort="fathername">
                                    <span>👨‍👦 Father's Name</span>
                                    <span class="sort-indicator">↓</span>
                                </th>
                                <th class="sortable" data-sort="created_at">
                                    <span>📅 Created At</span>
                                    <span class="sort-indicator">↓</span>
                                </th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT * FROM users ORDER BY id DESC";
                            $result = mysqli_query($conn, $query);

                            if (mysqli_num_rows($result) > 0) {
                                while ($data = mysqli_fetch_assoc($result)) {
                                    echo "<tr>
                                            <td>
                                                <div class='user-info'>
                                                    <div class='user-avatar'>".strtoupper(substr($data['username'], 0, 1))."</div>
                                                    <div class='user-details'>
                                                        <div class='user-name'>{$data['username']}</div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <span class='badge badge-primary'>{$data['sapid']}</span>
                                            </td>
                                            <td>{$data['fathername']}</td>
                                            <td>
                                                <div class='date-info'>
                                                    <div class='date'>{$data['created_at']}</div>
                                                </div>
                                            </td>
                                            <td>
                                                <div class='action-buttons'>
                                                    <button class='btn-action btn-edit' title='Edit Student'>
                                                        <span>✏️</span>
                                                    </button>
                                                    <button class='btn-action btn-delete' title='Delete Student'>
                                                        <span>🗑️</span>
                                                    </button>
                                                </div>
                                            </td>
                                          </tr>";
                                }
                            } else {
                                echo "<tr>
                                        <td colspan='5' class='no-data'>
                                            <div class='no-data-content'>
                                                <span class='no-data-icon'>📝</span>
                                                <h3>No Student Records Found</h3>
                                                <p>Add your first student to get started</p>
                                            </div>
                                        </td>
                                      </tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Table sorting functionality
        document.addEventListener('DOMContentLoaded', function() {
            const sortableHeaders = document.querySelectorAll('.sortable');
            
            sortableHeaders.forEach(header => {
                header.addEventListener('click', function() {
                    const sortBy = this.dataset.sort;
                    const currentOrder = this.querySelector('.sort-indicator').textContent;
                    const newOrder = currentOrder === '↓' ? '↑' : '↓';
                    
                    // Reset all sort indicators
                    document.querySelectorAll('.sort-indicator').forEach(indicator => {
                        indicator.textContent = '↓';
                    });
                    
                    // Set new sort indicator
                    this.querySelector('.sort-indicator').textContent = newOrder;
                    
                    // Here you would typically make an AJAX call to sort the data
                    console.log(`Sort by: ${sortBy}, Order: ${newOrder}`);
                });
            });
            
            // Form validation
            const form = document.querySelector('.advanced-form');
            form.addEventListener('submit', function(e) {
                const inputs = form.querySelectorAll('.form-input');
                let isValid = true;
                
                inputs.forEach(input => {
                    if (!input.value.trim()) {
                        input.classList.add('error');
                        isValid = false;
                    } else {
                        input.classList.remove('error');
                    }
                });
                
                if (!isValid) {
                    e.preventDefault();
                    alert('Please fill in all required fields!');
                }
            });
        });
    </script>
</body>
</html>