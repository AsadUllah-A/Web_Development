<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Management</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="header-content">
            <div class="logo">
                <span class="logo-icon">🎓</span>
                Student Management System
            </div>
            <nav>
                <ul>
                    <li><a href="student.php" class="nav-link">Students</a></li>
                    <li><a href="course.php" class="nav-link active">Courses</a></li>
                    <li><a href="courseadd.php" class="nav-link">Registration</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container">
        <?php
        $conn = mysqli_connect("localhost", "root", "", "student_management");

        if (!$conn) {
            die("SQL connection problem: " . mysqli_connect_error());
        }

        if (isset($_POST['submit'])) {
            $course_name = mysqli_real_escape_string($conn, $_POST['course_name']);
            $course_code = mysqli_real_escape_string($conn, $_POST['course_code']);
            $instructor = mysqli_real_escape_string($conn, $_POST['instructor']);
            $credits = $_POST['credits'];
            $duration = $_POST['duration'];

            // Check if fields are empty
            if (empty($course_name) || empty($course_code) || empty($instructor) || empty($credits) || empty($duration)) {
                echo "<div class='alert alert-danger'>Please fill in all the fields!</div>";
            } else {
                $query = "INSERT INTO courses (course_name, course_code, instructor, credits, duration) VALUES ('$course_name', '$course_code', '$instructor', '$credits', '$duration')";
                $result = mysqli_query($conn, $query);

                if ($result) {
                    echo "<div class='alert alert-success'>Course added successfully!</div>";
                } else {
                    echo "<div class='alert alert-danger'>Error adding course: " . mysqli_error($conn) . "</div>";
                }
            }
        }
        ?>

        <div class="card">
            <div class="card-header">
                <h2 class="card-title">
                    <span class="icon">📚</span>
                    Add New Course
                </h2>
                <p class="card-subtitle">Create a new course in the curriculum</p>
            </div>
            <div class="card-body">
                <form action="" method="post" class="advanced-form">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="course_name" class="form-label">
                                <span class="label-icon">📖</span>
                                Course Name
                            </label>
                            <input type="text" name="course_name" class="form-input" placeholder="Enter course name">
                            <div class="form-hint">Full name of the course</div>
                        </div>
                        
                        <div class="form-group">
                            <label for="course_code" class="form-label">
                                <span class="label-icon">🔤</span>
                                Course Code
                            </label>
                            <input type="text" name="course_code" class="form-input" placeholder="Enter course code">
                            <div class="form-hint">Unique course identifier</div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="instructor" class="form-label">
                            <span class="label-icon">👨‍🏫</span>
                            Instructor
                        </label>
                        <input type="text" name="instructor" class="form-input" placeholder="Enter instructor name">
                        <div class="form-hint">Name of course instructor</div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="credits" class="form-label">
                                <span class="label-icon">⭐</span>
                                Credits
                            </label>
                            <select name="credits" class="form-select" required>
                                <option value="">Select Credits</option>
                                <option value="1">1 Credit</option>
                                <option value="2">2 Credits</option>
                                <option value="3">3 Credits</option>
                                <option value="4">4 Credits</option>
                                <option value="5">5 Credits</option>
                            </select>
                            <div class="form-hint">Credit hours for this course</div>
                        </div>
                        
                        <div class="form-group">
                            <label for="duration" class="form-label">
                                <span class="label-icon">⏰</span>
                                Duration
                            </label>
                            <select name="duration" class="form-select" required>
                                <option value="">Select Duration</option>
                                <option value="3 Months">3 Months</option>
                                <option value="6 Months">6 Months</option>
                                <option value="1 Year">1 Year</option>
                                <option value="2 Years">2 Years</option>
                                <option value="4 Years">4 Years</option>
                            </select>
                            <div class="form-hint">Course duration period</div>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" name="submit" class="btn btn-primary">
                            <span class="btn-icon">➕</span>
                            Add Course
                        </button>
                        <button type="reset" class="btn btn-secondary">
                            <span class="btn-icon">🔄</span>
                            Reset Form
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h2 class="card-title">
                    <span class="icon">📋</span>
                    Course Catalog
                </h2>
                <div class="card-actions">
                    <span class="record-count">Total: 
                        <?php
                        $count_query = "SELECT COUNT(*) as total FROM courses";
                        $count_result = mysqli_query($conn, $count_query);
                        $count_data = mysqli_fetch_assoc($count_result);
                        echo $count_data['total'];
                        ?>
                    </span>
                </div>
            </div>
            <div class="card-body">
                <div class="table-container">
                    <table class="advanced-table">
                        <thead>
                            <tr>
                                <th class="sortable" data-sort="course_name">
                                    <span>📖 Course Name</span>
                                    <span class="sort-indicator">↓</span>
                                </th>
                                <th class="sortable" data-sort="course_code">
                                    <span>🔤 Course Code</span>
                                    <span class="sort-indicator">↓</span>
                                </th>
                                <th class="sortable" data-sort="instructor">
                                    <span>👨‍🏫 Instructor</span>
                                    <span class="sort-indicator">↓</span>
                                </th>
                                <th class="sortable" data-sort="credits">
                                    <span>⭐ Credits</span>
                                    <span class="sort-indicator">↓</span>
                                </th>
                                <th class="sortable" data-sort="duration">
                                    <span>⏰ Duration</span>
                                    <span class="sort-indicator">↓</span>
                                </th>
                                <th class="sortable" data-sort="created_at">
                                    <span>📅 Created At</span>
                                    <span class="sort-indicator">↓</span>
                                </th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $query = "SELECT * FROM courses ORDER BY id DESC";
                            $result = mysqli_query($conn, $query);

                            if (mysqli_num_rows($result) > 0) {
                                while ($data = mysqli_fetch_assoc($result)) {
                                    echo "<tr>
                                            <td>
                                                <div class='course-info'>
                                                    <div class='course-avatar'>".strtoupper(substr($data['course_name'], 0, 1))."</div>
                                                    <div class='course-details'>
                                                        <div class='course-name'>{$data['course_name']}</div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <span class='badge badge-secondary'>{$data['course_code']}</span>
                                            </td>
                                            <td>{$data['instructor']}</td>
                                            <td>
                                                <span class='badge badge-credits'>{$data['credits']} Credit".($data['credits'] > 1 ? 's' : '')."</span>
                                            </td>
                                            <td>
                                                <span class='badge badge-duration'>{$data['duration']}</span>
                                            </td>
                                            <td>
                                                <div class='date-info'>
                                                    <div class='date'>{$data['created_at']}</div>
                                                </div>
                                            </td>
                                            <td>
                                                <div class='action-buttons'>
                                                    <button class='btn-action btn-edit' title='Edit Course'>
                                                        <span>✏️</span>
                                                    </button>
                                                    <button class='btn-action btn-delete' title='Delete Course'>
                                                        <span>🗑️</span>
                                                    </button>
                                                </div>
                                            </td>
                                          </tr>";
                                }
                            } else {
                                echo "<tr>
                                        <td colspan='7' class='no-data'>
                                            <div class='no-data-content'>
                                                <span class='no-data-icon'>📚</span>
                                                <h3>No Courses Found</h3>
                                                <p>Add your first course to get started</p>
                                            </div>
                                        </td>
                                      </tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>