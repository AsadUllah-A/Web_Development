<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Course Registration</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="header-content">
            <div class="logo">
                <span class="logo-icon">🎓</span>
                Student Management System
            </div>
            <nav>
                <ul>
                    <li><a href="student.php" class="nav-link">Students</a></li>
                    <li><a href="course.php" class="nav-link">Courses</a></li>
                    <li><a href="courseadd.php" class="nav-link active">Registration</a></li>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container">
        <?php
        $conn = mysqli_connect("localhost", "root", "", "student_management");

        if (!$conn) {
            die("SQL connection problem: " . mysqli_connect_error());
        }

        // Handle form submission
        if (isset($_POST['submit'])) {
            $user_id = $_POST['user_id'];
            $course_id = $_POST['course_id'];

            // Check if fields are empty
            if (empty($user_id) || empty($course_id)) {
                echo "<div class='alert alert-danger'>Please select both user and course!</div>";
            } else {
                $query = "INSERT INTO user_courses (user_id, course_id) VALUES ('$user_id', '$course_id')";
                $result = mysqli_query($conn, $query);

                if ($result) {
                    echo "<div class='alert alert-success'>Course registered successfully!</div>";
                } else {
                    // Check if it's a duplicate entry error
                    if (mysqli_errno($conn) == 1062) {
                        echo "<div class='alert alert-warning'>This user is already registered for this course!</div>";
                    } else {
                        echo "<div class='alert alert-danger'>Error registering course: " . mysqli_error($conn) . "</div>";
                    }
                }
            }
        }
        ?>

        <div class="card">
            <div class="card-header">
                <h2 class="card-title">
                    <span class="icon">🎯</span>
                    Course Registration
                </h2>
                <p class="card-subtitle">Register students for courses</p>
            </div>
            <div class="card-body">
                <form action="" method="post" class="advanced-form">
                    <div class="form-row">
                        <div class="form-group">
                            <label for="user_id" class="form-label">
                                <span class="label-icon">👨‍🎓</span>
                                Select Student
                            </label>
                            <select name="user_id" class="form-select" required>
                                <option value="">Select Student</option>
                                <?php
                                $users_query = "SELECT id, username, sapid FROM users ORDER BY username";
                                $users_result = mysqli_query($conn, $users_query);
                                
                                if (mysqli_num_rows($users_result) > 0) {
                                    while ($user = mysqli_fetch_assoc($users_result)) {
                                        echo "<option value='{$user['id']}'>{$user['username']} ({$user['sapid']})</option>";
                                    }
                                } else {
                                    echo "<option value=''>No students found</option>";
                                }
                                ?>
                            </select>
                            <div class="form-hint">Choose a student to register</div>
                        </div>
                        
                        <div class="form-group">
                            <label for="course_id" class="form-label">
                                <span class="label-icon">📚</span>
                                Select Course
                            </label>
                            <select name="course_id" class="form-select" required>
                                <option value="">Select Course</option>
                                <?php
                                $courses_query = "SELECT id, course_name, course_code FROM courses ORDER BY course_name";
                                $courses_result = mysqli_query($conn, $courses_query);
                                
                                if (mysqli_num_rows($courses_result) > 0) {
                                    while ($course = mysqli_fetch_assoc($courses_result)) {
                                        echo "<option value='{$course['id']}'>{$course['course_name']} ({$course['course_code']})</option>";
                                    }
                                } else {
                                    echo "<option value=''>No courses found</option>";
                                }
                                ?>
                            </select>
                            <div class="form-hint">Choose a course for registration</div>
                        </div>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" name="submit" class="btn btn-primary">
                            <span class="btn-icon">✅</span>
                            Register Course
                        </button>
                        <button type="reset" class="btn btn-secondary">
                            <span class="btn-icon">🔄</span>
                            Reset Form
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h2 class="card-title">
                    <span class="icon">📋</span>
                    Course Registrations
                </h2>
                <div class="card-actions">
                    <span class="record-count">Total: 
                        <?php
                        $count_query = "SELECT COUNT(*) as total FROM user_courses";
                        $count_result = mysqli_query($conn, $count_query);
                        $count_data = mysqli_fetch_assoc($count_result);
                        echo $count_data['total'];
                        ?>
                    </span>
                </div>
            </div>
            <div class="card-body">
                <div class="table-container">
                    <table class="advanced-table">
                        <thead>
                            <tr>
                                <th class="sortable" data-sort="id">
                                    <span># ID</span>
                                    <span class="sort-indicator">↓</span>
                                </th>
                                <th class="sortable" data-sort="username">
                                    <span>👤 Student</span>
                                    <span class="sort-indicator">↓</span>
                                </th>
                                <th class="sortable" data-sort="sapid">
                                    <span>🆔 SAP ID</span>
                                    <span class="sort-indicator">↓</span>
                                </th>
                                <th class="sortable" data-sort="course_name">
                                    <span>📚 Course</span>
                                    <span class="sort-indicator">↓</span>
                                </th>
                                <th class="sortable" data-sort="course_code">
                                    <span>🔤 Code</span>
                                    <span class="sort-indicator">↓</span>
                                </th>
                                <th class="sortable" data-sort="registered_at">
                                    <span>📅 Registered At</span>
                                    <span class="sort-indicator">↓</span>
                                </th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $registrations_query = "
                                SELECT uc.id, uc.registered_at, 
                                       u.username, u.sapid, 
                                       c.course_name, c.course_code 
                                FROM user_courses uc
                                JOIN users u ON uc.user_id = u.id
                                JOIN courses c ON uc.course_id = c.id
                                ORDER BY uc.registered_at DESC
                            ";
                            $registrations_result = mysqli_query($conn, $registrations_query);

                            if (mysqli_num_rows($registrations_result) > 0) {
                                while ($registration = mysqli_fetch_assoc($registrations_result)) {
                                    echo "<tr>
                                            <td>
                                                <span class='badge badge-id'>#{$registration['id']}</span>
                                            </td>
                                            <td>
                                                <div class='user-info'>
                                                    <div class='user-avatar'>".strtoupper(substr($registration['username'], 0, 1))."</div>
                                                    <div class='user-details'>
                                                        <div class='user-name'>{$registration['username']}</div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <span class='badge badge-primary'>{$registration['sapid']}</span>
                                            </td>
                                            <td>
                                                <div class='course-info'>
                                                    <div class='course-avatar'>".strtoupper(substr($registration['course_name'], 0, 1))."</div>
                                                    <div class='course-details'>
                                                        <div class='course-name'>{$registration['course_name']}</div>
                                                    </div>
                                                </div>
                                            </td>
                                            <td>
                                                <span class='badge badge-secondary'>{$registration['course_code']}</span>
                                            </td>
                                            <td>
                                                <div class='date-info'>
                                                    <div class='date'>{$registration['registered_at']}</div>
                                                </div>
                                            </td>
                                            <td>
                                                <span class='status-badge status-active'>Active</span>
                                            </td>
                                          </tr>";
                                }
                            } else {
                                echo "<tr>
                                        <td colspan='7' class='no-data'>
                                            <div class='no-data-content'>
                                                <span class='no-data-icon'>📝</span>
                                                <h3>No Course Registrations</h3>
                                                <p>Register a student for a course to get started</p>
                                            </div>
                                        </td>
                                      </tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</body>
</html>